#include "BitMap.cpp"
#include "TLB.cpp"
#include <bitset>
#include <iostream>
#include <sstream>
using namespace std;

class phys_mem{
	int * PM = new int[524288];
	BitMap BM = BitMap();
	TLB buffer = TLB();
	int mask9; //mask for last 9 bits of a number
	int mask10; //mask for last 10 bits of a number
	
	int s; //these are used to store the results from interpret_VA, since it would return 3 values
	int p;
	int w;
	
	public:

		//Physical Mem is an array of integers, divided into 1024 frames of 512 integers each. (=524,288 integers, = 2 MegaBytes)
		//The first frame (frame 0) is the segment table ST (512 integers long)
		//each page table PT occupies 2 consecutive frames (1024 integers long)
		//each program/data page occupies 1 frame
		
		//virtual address VA = blanl (4 bits), segment # s (9 bits), page # p (10 bits), offset within page # w (9 bits)
		//leading 4 bits of VA are unused
		
		//PM[ S ] accesses the ST, and gives us the starting address of a PT
		//PM[ PM[S] + P] accesses the PT, and gives us the starting address of a page
		//all ST/PT entries are multiples of 512 (so they are addresses, not frame numbers)
		
		phys_mem(){
			for(int i = 0; i < 524288; i++){
				PM[i] = 0;
			}
			mask9 = 1; 
			for (int i = 0; i < 8; i++){ //initialize mask9
				mask9 = mask9 << 1;
				mask9 += 1;
			}
			
			mask10 = 1; 
			for (int i = 0; i < 9; i++){ //initialize mask10
				mask10 = mask10 << 1;
				mask10 += 1;
			}
		}
		~phys_mem(){
			delete[] PM;
		}
		
		void init_line1(int s, int f){
			//PT of segment s starts at address f, so ST[s] = f, or PM[s] = f
			
			PM[s] = f;
			
			if (s >= 0 && f > 0){ //bit allocation
				int i = f / 512;
				BM.setTo1(i);
				BM.setTo1(i+1);
				//cout << "page table of segment " << s << " assigned to frame numbers " << i <<" and " << i + 1 << endl;
				//cout << "at end of init_line1, PM[s] = " << PM[s] << endl;
			}
		}
		void init_line2(int p, int s, int f){
			//page p of segment s starts at index f, so ST[s] -> PT[p] = f, or PM[PM[s] + p] = f
			//cout << "p is: " << p << endl;
			//cout << "s is: " << s << endl;
			//cout << "f is: " << f << endl;
			if (PM[s] > 0){ //avoid error
				PM[PM[s] + p] = f;
				//cout << "PM[" << s << "] = " << PM[s] << endl;
				//cout << "PM[" << s << "] + " << p << " = " << PM[s] + p << endl;
				int b = (PM[s] + p) / 512;
				BM.setTo1(b);
				//cout << "page " << p << " of segment " << s << " assigned data to frame number " << b << " allocated in bitmap to have value " << PM[PM[s]+p] << endl;
			}
			
			
		}
		
		void interpret_VA(int VA){
			//break virtual address VA into s, p, w (segment #, page #, word #)
			w = VA & mask9;
			//cout << "w is " << w << endl;
			p = (VA >> 9) & mask10;
			//cout << "p is " << p << endl;
			s = (VA >> 19) & mask9;
			//cout << "s is " << s << endl;
		}
		
		string read_page(int VA){
			interpret_VA(VA);
			//if ST or PT entry == -1, output pf (page fault) and continue to next VA
			if (PM[s] == -1 || PM[PM[s] + p] == -1){
				//cout << "page fault encountered" << endl;
				return "pf";
			}
			//if ST or PT entry == 0, output error and continue to next VA
			else if (PM[s] == 0 || PM[PM[s] + p] == 0){
				//cout << "error encountered" << endl;
				return "err";
			}
			//else, output PA = PM[PM[s] + p] + w
			else{
				//cout << "valid VA encountered" << endl;
				int to_return = PM[PM[s] + p] + w;
				//cout << "result: " << to_string(to_return) << endl;
				return to_string(to_return);
			}
		}
		
		string write_page(int VA){
			interpret_VA(VA);
			//if ST or PT entry == -1, output pf (page fault) and continue to next VA
			//cout << "write: ST entry is " << PM[s] << " and PT entry is " << PM[PM[s] + p] << endl;
			if (PM[s] == -1 || PM[PM[s] + p] == -1){
				//cout << "page fault encountered" << endl;
				return "pf";
			}
			//if ST entry == 0, 
				////allocate a new blank PT (all zeroes)
				//update the ST entry to point to the PT
				//continue with translation process
			if (PM[s] == 0){
				//cout << "ST entry is 0" << endl;
				int i = -1;
				int j = -1;
				while (j == -1){
					i = BM.searchForDouble0();
					if (BM.getBit(i + 1) == 0){ // if we have found 2 consecutive empty frames for the PT
						j = i + 1;
						BM.setTo1(i);
						BM.setTo1(j);
					}
				}
				PM[s] = i * 512;
			}
			//if PT entry == 0.
				//create a new blank page
				//update the PT entry with the page number
				//continue with the translation process
			if (PM[PM[s] + p] == 0){
				//cout << "PT entry is 0" << endl;
				int i = BM.searchFor0(); //find spot for the new page
				//cout << "0 found at index: " << i << endl;
				BM.setTo1(i);
				//cout << "new page created at frame " << i<< endl;
				PM[PM[s] + p] = i * 512;
				//cout << "PT entry updated to " << PM[PM[s] + p] << endl;
				int to_return = PM[PM[s] + p] + w;
				//cout << "result: " << to_string(to_return) << endl;
				return to_string(to_return);
				
			}
			//else, output the corresponding PA
			else{
				//cout << "valid PA encountered" << endl;
				int to_return = PM[PM[s] + p] + w;
				//cout << "result: " << to_string(to_return) << endl;
				return to_string(to_return);
			}
		}
		
		string read_page_TLB(int VA){
			//cout << "read operation" << endl;
			stringstream result;
			int hit_PA = buffer.find_hit(VA);
			if (hit_PA != -1){ //if we get a hit
				result << "h " << hit_PA;
				//cout << "TLB hit" << endl;
				//cout << "result: " << result.str() << endl;
				return result.str();
			}
			//if we get a miss
			result << "m ";
			//cout << "TLB miss" << endl;

			interpret_VA(VA);
			//if ST or PT entry == -1, output pf (page fault) and continue to next VA
			//cout << "read: ST entry is " << PM[s] << " and PT entry is " << PM[PM[s] + p] << endl;
			if (PM[s] == -1 || PM[PM[s] + p] == -1){
				//cout << "page fault encountered" << endl;
				result << "pf";
				return result.str();
			}
			//if ST or PT entry == 0, output error and continue to next VA
			else if (PM[s] == 0 || PM[PM[s] + p] == 0){
				//cout << "error encountered" << endl;
				result << "err";
				return result.str();
			}
			else{
				//cout << "valid VA encountered" << endl;
				int f = PM[PM[s] + p];
				buffer.update_TLB_from_miss(VA, f);
				int to_return = PM[PM[s] + p] + w;
				result << to_string(to_return);
				//cout << "result: " << result.str() << endl;
				return result.str();
			}
		}
		
		string write_page_TLB(int VA){
			//cout << "write operation" << endl;
			stringstream result;
			int hit_PA = buffer.find_hit(VA);
			if (hit_PA != -1){ //if we get a hit
				//cout << "TLB hit" << endl;
				//cout << "result: " << hit_PA << endl;
				result << "h " << hit_PA;
				return result.str();
			}
			//if we get a miss
			result << "m ";
			//cout << "TLB miss" << endl;
			
			interpret_VA(VA);
			//if ST or PT entry == -1, output pf (page fault) and continue to next VA
			//cout << "write: ST entry is " << PM[s] << " and PT entry is " << PM[PM[s] + p] << endl;
			if (PM[s] == -1 || PM[PM[s] + p] == -1){
				//cout << "page fault encountered" << endl;
				result << "pf";
				return result.str();
			}
			
			//if ST entry == 0, 
				////allocate a new blank PT (all zeroes)
				//update the ST entry to point to the PT
				//continue with translation process
			if (PM[s] == 0){
				//cout << "ST entry is 0" << endl;
				int i = -1;
				int j = -1;
				while (j == -1){
					i = BM.searchForDouble0();
					if (BM.getBit(i + 1) == 0){ // if we have found 2 consecutive empty frames for the PT
						j = i + 1;
						BM.setTo1(i);
						BM.setTo1(j);
					}
				}
				PM[s] = i * 512;
			}
			//if PT entry == 0.
				//create a new blank page
				//update the PT entry with the page number
				//continue with the translation process
			if (PM[PM[s] + p] == 0){
				//cout << "PT entry is 0" << endl;
				int i = BM.searchFor0(); //find spot for the new page
				//cout << "0 found at index: " << i << endl;
				BM.setTo1(i);
				//cout << "new page created at frame " << i<< endl;
				PM[PM[s] + p] = i * 512;
				//cout << "PT entry updated to " << PM[PM[s] + p] << endl;
				int to_return = PM[PM[s] + p] + w;
				//cout << "result: " << to_string(to_return) << endl;
				result << to_string(to_return);
				return result.str();
			}
			//else, output the corresponding PA
			else{
				//cout << "valid PA encountered" << endl;
				int f = PM[PM[s] + p];
				buffer.update_TLB_from_miss(VA, f);
				int to_return = PM[PM[s] + p] + w;
				result << to_string(to_return);
				//cout << "result: " << result.str() << endl;
				return result.str();
			}
		}
	
};

