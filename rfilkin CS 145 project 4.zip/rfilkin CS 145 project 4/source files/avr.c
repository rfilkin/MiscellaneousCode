#include "avr.h"

void
ini_avr(void)
{
	WDTCR = 15;
}

void
wait_avr(unsigned short msec)
{
	TCCR0 = 3;
	while (msec--) {
		TCNT0 = (unsigned char)(256 - (XTAL_FRQ / 64) * 0.001); // 1 msec units
		SET_BIT(TIFR, TOV0);
		WDR();
		while (!GET_BIT(TIFR, TOV0));
	}
	TCCR0 = 0;
}

void
wait_avr2(unsigned short t_msec)
{
	TCCR0 = 2;
	while (t_msec--) {
		TCNT0 = (unsigned char)(256 - (XTAL_FRQ / 8) * 0.00005); // 1/20,000 sec units
		SET_BIT(TIFR, TOV0);
		//WDR();
		while (!GET_BIT(TIFR, TOV0));
	}
	TCCR0 = 0;
}

int is_pressed(int r, int c){

	DDRC = 0; //clears DDRC
	SET_BIT(DDRC, c); //sets column to strong 0

	PORTC = 0; //clears PORTC
	SET_BIT(PORTC, r + 4); //sets row to weak 1
	CLR_BIT(PORTC,c);
	wait_avr(1);
	
	if (GET_BIT(PINC, r + 4) == 0 ){ //if strong 0 overlaps weak 1, then button was pressed
		return 1;
	}
	return 0;
}

int get_key(void){
	for (int r = 0; r < 4; ++r){
		for (int c = 0; c < 4; ++c){
			if (is_pressed(c, r)){
				return r * 4 + c + 1;
			}
		}
	}
	return 0;
}