/*
 * Project4.c
 *
 * Created: 2/28/2018 1:33:21 PM
 * Author : rfilk
 */ 

#include <avr/io.h>
#include <stdio.h>
#include "avr.c"
#include "lcd.c"

float V_inst = -1;
float V_min = -1;
float V_max = -1;
float Vrunning_total = -1;
float V_num_measures = -1;
char buf[10];
int is_reading = 0;

void update_lcd()
{
	clr_lcd();
	pos_lcd(0,0);

	puts_lcd2("Ins:"); //-----------------------------------instantaneous V
	if (V_inst < 0)
	{
		puts_lcd2("----");
	}
	else
	{
		sprintf(buf, "%.2f", (float)V_inst);
		puts_lcd2(buf);
	}
	puts_lcd2("Avg:"); //------------------------------------average V
	if (Vrunning_total < 0 || V_num_measures <= 0)
	{
		puts_lcd2("----");
	}
	else
	{
		sprintf(buf, "%.2f", (float)(Vrunning_total / V_num_measures));
		puts_lcd2(buf);
	}

	pos_lcd(1,0); //--------------------move cursor to second row

	puts_lcd2("Min:"); //-----------------------------------Minimum V
	if (V_min < 0)
	{
		puts_lcd2("----");
	}
	else
	{
		sprintf(buf, "%.2f", (float)V_min);
		puts_lcd2(buf);
	}

	puts_lcd2("Max:"); //-----------------------------------Maximum V
	if (V_max < 0)
	{
		puts_lcd2("----");
	}
	else
	{
		sprintf(buf, "%.2f", (float)V_max);
		puts_lcd2(buf);
	}
}

void update_V_data(){
	if (V_min < 0 || V_inst < V_min){ //update min
		V_min = V_inst;
	}

	if (V_max < 0 || V_max < V_inst){ //update max
		V_max = V_inst;
	}

	if (Vrunning_total <= 0){ //initialize running total
		Vrunning_total = V_inst;
	}
	else { //add to running total
		Vrunning_total += V_inst;
	}

	if (V_num_measures <= 0){ //initialize count of measures
		V_num_measures = 1;
	}
	else{ //increase count of measures
		V_num_measures += 1;
	}
}

int main(void)
{
	ini_lcd(); //initialize LCD
	clr_lcd();
	pos_lcd(0,0);
	puts_lcd2("test1");

	CLR_BIT(DDRA, 0); //sets port A, bit 0 to input

	SET_BIT(ADMUX, 6); //sets voltage reference to "AVCC with external capacitor at AREF pin"
	CLR_BIT(ADMUX, 7);

	SET_BIT(ADCSRA, 7); //sets enable bit for ADC

	while (1)
	{
		if (get_key() == 4){ //toggle auto-measuring (A key)
			is_reading = 1;
		}
		else if (get_key() == 12){ //clear display & stop measuring (C key)
			is_reading = 0;
			V_inst = -1;
			V_min = -1;
			V_max = -1;
			Vrunning_total = -1;
			V_num_measures = -1;
		}

		if (is_reading == 1){ 
			SET_BIT(ADCSRA, 6); //sets start_conversion bit in ADC, which will automatically change back to 0 when done.
			while (GET_BIT(ADCSRA, 6) != 0){
				//waits for conversion to finish
			}
			float measurement = ADC; //gets 16 bits from the ADC register
			V_inst = (measurement / 1024.00) * 5.00; //divide by 2^10 (or 1024) then multiply by 5 to get voltage, assuming a voltage range of 1-5V.

			update_V_data();
			update_lcd();
			wait_avr(500);
		}
		else{
			update_lcd();
		}
		
	}
}
