#include "IOSystem.cpp"
#include <iostream>
using namespace std;

class OFT{
	public:
	//OFT has 4 rows: index 0 is reserved for directory, while the other 3 rows are for other files
	//each entry is [76 bytes = r/w buffer (16 integers, 64 bytes) | current position in file (integer, 4 bytes) | file descriptor index (integer, 4 bytes) | length (integer, 4 bytes)]
	char table[4][76]; 
	IOSys io;
	
	OFT(IOSys IO){
		//initialize with empty bytes
		io = IO;
		
		//first fill bytes with placeholders
		for (int i = 0; i < 4; i++){
			for(int j = 0; j < 76; j++){
				table[i][j] = -1;
			}
		}
		
		//fill the table such that its values can be found with a typecasted int
		for(int i = 0; i < 4; i++){
			int* temp = (int*) table[i];
			for (int j = 0; j < 19; j++){
				temp[j] = -1;
			}
		}
		
		//initialize the directory's current position to 0
		setPosition(0,0);
		//initialize the directory's file index to 0
		setIndex(0,0);
		setLength(0,0);
		//each slot of directory is [symbolic name of file (4 chars/bytes, 1 integer) | descriptor index (4 bytes, 1 integer)]. [so each block holds 8 slots]
	}
	
	void setPosition(int oftEntry, int newPosition){
		int * temp = (int *) table[oftEntry]; //int typecast pointer
		temp[16] = newPosition;
	}
	void setIndex(int oftEntry, int newIndex){
		int * temp = (int *) table[oftEntry]; //int typecast pointer
		temp[17] = newIndex;
	}
	
	void setLength(int oftEntry, int newLength){
		int * temp = (int *) table[oftEntry]; //int typecast pointer //&table[oftEntry][0]
		temp[18] = newLength;
	}
	
	int getPosition(int oftEntry){ //returns current position in the file
		int * temp = (int *) table[oftEntry];
		return temp[16];
	}
	int getIndex(int oftEntry){ //returns file descriptor index
		int * temp = (int *) table[oftEntry];
		//cout << "fetching index at oft entry " << oftEntry << endl;
		//cout << "length of casted oft is " << sizeof(temp) << endl;
		//cout << "temp 17 is " << temp[17] << endl;
		return temp[17];
	}
	int getLength(int oftEntry){ //returns length of file
		int * temp = (int *) table[oftEntry];
		return temp[18];
	}
	
	int findFreeOFTEntry(){
		for (int i = 1; i <= 3; i++){
			//cout << "position of oft entry " << i << " is " << getPosition(i) << endl;
			if (getPosition(i) == -1){
				//cout << "found free oft entry at index " << i << endl;
				return i;
			}
			
		}
		return -1;
	}
	
	~OFT(){
	}
};
