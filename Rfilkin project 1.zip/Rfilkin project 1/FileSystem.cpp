#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <string.h>
#include "OFT.cpp"
#include "BitMap.cpp"

using namespace std;
/*
o	ldisk: 64 blocks
o	block = 64B = 16 integers
o	block 0 holds bitmap: 64 bits (one per block) = 2 integers
o	descriptor: 4 integers
o	file length (1 int)
o	3 block #s
o	# of descriptors: 24 = 6 blocks
o	descriptor 0 describes the directory
o	each directory entry: 2 integers
o	file name: maximum 4 chars, no extension (1 int)
o	descriptor index: 1 integer
o	ldisk can be saved into a text file at any point with the sv command
o	ldisk can be restored from a previously saved text file ising the in command
o	a new empty ldisk is created if no saved file is given
o	directory is opened automatically with in command (OFT index = 0) 
o	OFT has 4 entries: directory plus up to 3 other open files
o	all files (including directory) must close with sv command
o	destroying an open file is ok (not an error)
o	every open command must use the first available slot in the OFT (smallest index)


ldisk:
- array of 64 blocks
- block 0 holds the bitmap
- first k disk blocks [1..k] (not 0) are reserved for file descriptors 
- remaining blocks [k+1...64] contain file data blocks.

directory:
- file 0 in disk block 1
- unsorted array of slots
- each slot contains a symbolic name of a file(max 4 chars = 1 integer), and descriptor index (4 chars, 1 integer)

file descriptors
- first k disk blocks [1..k] (not 0) are reserved for file descriptors
- each contains length of file (in bytes), and disk map (4 + 4 + 4 + 4 = 16 bytes)
- disk map: fixed list of maximum 3 disk blocks (max length of a file)

data
- remaining disk blocks after [k] are used for storing data
*/

class FileSys{
	public:
		IOSys IO = IOSys();
		OFT oft = OFT(IO);
		BitMap BM = BitMap();
		
		FileSys(){
			//update_disk_BM(); //set bit map
			open_directory();
			//BM.printBitMap();
			
		}
		
		int create(char* symbolic_file_name){
			//find a free file descriptor slot (in ldisk blocks [1-6], 4 descriptors per block, so 24 total slots)
				//read the file sequentially one slot at a time, to see if the slot is free
				
			int descIndex = -1;	
			for(int i = 1; i < 24; i++){
				if (descriptorGetLength(i) == -1){ //if length = -1, then we have found an empty descriptor
					descIndex = i;
					descriptorSetLength(i, 0);
					break;
				}
			}

			if (descIndex == -1){ //if we failed to find an empty descriptor slot
				cout << "error: create failed to find an empty descriptor slot" << endl;
				return -1;
			}
			
			//search directory for a free directory entry (in ldisk block 0, file 0)
				////seek to the beginning of the (open) directory file
				////read the file sequentially one slot at a time, to see if the slot is free
				////once a free slot is found, fill it with the 4-byte file name and 4-byte index descIndex
				
			lseek(0,0); //seek to beginning of directory file
			char temp [192];
			int bytes_read = read(0, temp, 192); //read directory into local char* temp
			int * temp2 = (int *) temp; //typecast directory into array of integers, 2 integers per slot.
			int * symbolic_int = (int *) symbolic_file_name; //casts our file name into an integer for easier comparison
			int temp2_size = bytes_read / 4; //size of the integer type-casted array. ranges from 0-48 (192 / 4 since 4 char = 1 int)
			
			bool found_slot = false;
			
			for (int i = 0; i < temp2_size; i+=2){ //for each slot in the directory
				if (temp2[i] == symbolic_int[0]){ //if the file we want to create already exists
					cout << "error: file with name "<< symbolic_file_name << " has already been created" << endl;
					return -1;
				}
				else if (temp2[i + 1] == -1){ //if we have found a free directory entry (descIndex = -1) somewhere in the middle of directory
					temp2[i] = symbolic_int[0]; //put the file's new name into this slot
					temp2[i + 1] = descIndex; //copy the descriptor index into this slot
					lseek(0,i); //seek to this slot's position in the directory
					for (int j = 0; j < 8; j++){ //write into the directory file 8 bytes: 4 bytes for symbolic name (= 1 integer) | 4 bytes for descIndex (= 1 integer)
						write(0, temp[i*4 + j], 1);
					}
					//directory();
					found_slot = true;
					break;
				}
			}
			
			if (!found_slot){ //if we couldn't find an empty slot somewhere in the middle
				char to_write[8];
				int * to_write2 = (int *) to_write;
				to_write2[0] = symbolic_int[0];
				to_write2[1] = descIndex;
				//lseek(0, bytes_read); //seek to the end of the current directory
				for (int i = 0; i < 8; i++){ //write a slot towards the end of the file
					write(0, to_write[i], 1);
					//cout << "wrote char " << to_write[i] << " to end of directory" << endl;
				}
			}
	
			return 1;
		}
		
		int destroy(char* symbolic_file_name){
			//search directory for the file descriptor
				//seek to the beginning of the (open) directory file
				//read the file sequentially one slot at a time, to see if the slot is a match
				//if no match is found, "error: no such file". If a match is found, then continue
				//remove directory entry by marking it with -1, but save index descIndex for later
				//free the file descriptor at block index descIndex in the disk
				
				int * symbolic_int = (int* ) symbolic_file_name;
				int descIndex = findFileDescriptorIndex(symbolic_file_name);
				
				lseek(0, descIndex * 8);
				char to_write[8];
				int * to_write2 = (int *) to_write;
				to_write2[0] = -1;
				to_write2[1] = -1;
				for (int i = 0; i < 8; i++){
					write(0, to_write[i], 1); //remove directory entry by marking each of its 2 integers as -1
				}
				
				if (descIndex == -1){ //if we failed to find the file we wanted to destroy
					cout << "error: destroy could not find specified file";
					return -1;
				}
				
				//free the file descriptor at block index descIndex in the disk
				char temp[64];
				IO.read_block(descIndexToBlock(descIndex), temp); //read the appropriate block in disk
				//cout << "we want to free the descriptor at descIndex " << descIndex << endl;
				int* temp2 = (int *) temp; //typecast block to array of 16 integers, 4 integers per descriptor
				int offset = descIndex % 4; //determines the local index we must access within the block
				//cout << "Our offset will be " << offset << endl;
				int length = temp2[offset * 4]; 
				temp2[offset * 4] = -1; //set the first integer of the descriptor, the length, to -1.
				IO.write_block(descIndexToBlock(descIndex), temp);
				
				//if the removed file was not empty, then update bit map to free the blocks listed in the file descriptor
				if (length != 0){ //if the file's length is not 0, we have to update the bit map
					for (int i = 1; i < 4; i++){
						BM.setTo0(temp2[offset * 4 + i]);
						//update_disk_BM();
					}
				}
				return 1;
		}
		
		int open(char* symbolic_file_name){
			//seek to beginning of directory and search sequentially for index of the file descriptor (index descIndex)
			int * symbolic_int = (int* ) symbolic_file_name;
			int descIndex = findFileDescriptorIndex(symbolic_file_name);
			//cout << "opened file " << symbolic_file_name << ". file descriptor index is " << descIndex << endl;
			
			if (descIndex == -1){
				cout << "error: open could not find the specified file" << endl;
				return -1;
			}
			
			for (int i = 1; i < 4; i++){
				if (oft.getLength(i) != -1){
					if (oft.getIndex(i) == descIndex){
						cout << "error: specified file is already open" << endl;
						return -1;
					}
				}
			}
			
			//cout << "no error so far" << endl;
			
			//look for the file descriptor at index descIndex and find the file length L
			int fileLength = descriptorGetLength(descIndex);
			//cout << "found length of file " << symbolic_file_name << " the specified file: " << fileLength << endl;
			
			//allocate a free OFT entry at index j (reuse deleted entries)
				////fill in current position as 0, file descriptor index as index descIndex, length as length L
			
			int free_spot = oft.findFreeOFTEntry();
			//cout << "free entry found at index " << free_spot << endl;
			oft.setPosition(free_spot, 0);
			oft.setIndex(free_spot, descIndex);
			oft.setLength(free_spot, fileLength);
			
			//read block 0 of file into the r/w buffer (read-ahead)
			//(figure out where block 0 of the file is)
			int readAheadIndex = descriptorGetDiskBlockIndex(descIndex, 0);
			//cout << "readAheadIndex for file " << symbolic_file_name << " is " << readAheadIndex << endl;
			
			if (readAheadIndex == -1){
				//if block 0 of the file is -1, we have not allocated its first block yet. 
				//to do that, search for a free bit in bit map, update the file descriptor's first data block location, and update the bit map
				//cout << "before new file block allocated: " << endl;
				//BM.printBitMap();
				int bit_index = BM.searchFor0();
				//cout << "opening file " << symbolic_file_name << " set bit " << bit_index << " to 1" << endl;
				BM.setTo1(bit_index);
				//update_disk_BM();
				descriptorSetDiskBlockIndex(descIndex, 0, bit_index);
				//cout << "new file block allocated: " << endl;
				//BM.printBitMap();
				readAheadIndex = bit_index;
				//cout << "opened file " << symbolic_file_name << " had no blocks, so block " << bit_index << " was allocated." << endl;
			}
			IO.read_block(readAheadIndex, oft.table[free_spot]);
			
			//return OFT index (j) (or return error)
			return free_spot;
		
		}
		int open_directory(){
			//cout << "opening directory" << endl;
			int descIndex = 0;
			int fileLength = descriptorGetLength(0);
			if (fileLength == -1){
				fileLength = 0; //sets initial length to 0 when we first create the directory
			}
			
			int free_spot = 0;
			
			oft.setPosition(free_spot, 0);
			//cout << "position of directory is "<< oft.getPosition(descIndex) << endl;
			oft.setIndex(free_spot, descIndex);
			//cout << "index of directory is " << oft.getIndex(descIndex) << endl;
			oft.setLength(free_spot, fileLength);
			//cout << "length of directory is " << oft.getLength(descIndex) << endl;

			int readAheadIndex = descriptorGetDiskBlockIndex(descIndex, 0);
			//cout << "read ahead disk: " << readAheadIndex << endl;
			if (readAheadIndex == -1){
				//if block 0 of the file is -1, we have not allocated its first block yet. 
				//to do that, search for a free bit in bit map, update the file descriptor's first data block location, and update the bit map
				//cout << "before new file block allocated: " << endl;
				//BM.printBitMap();
				int bit_index = 7; //find an empty bit
				//cout <<"while opening directory, found empty bit " << bit_index << endl;
				BM.setTo1(7); //set that bit to 1
				//update_disk_BM();
				descriptorSetDiskBlockIndex(descIndex, 0, bit_index);
				//cout << "new file block allocated: " << endl;
				//BM.printBitMap();
				readAheadIndex = bit_index;
				//cout << "opened directory had no blocks, so block " << bit_index << " was allocated." << endl;
				//cout << "corrected read ahead disk: " << readAheadIndex << endl;
			}
			
			IO.read_block(readAheadIndex, oft.table[free_spot]);
			//cout << "oft entry 0: " << oft.table[free_spot] << endl;
		}
		
		int close(int OFTindex){
			//write buffer to disk
				//use OFTindex to get the file descriptor's index
				//use OFTindex to get the file's length, 
				//use OFTindex to get the file's current position, use that to get which of the 3 blocks we should access (range from 0-2)
				//go to the file descriptor and look at the appropriate cell of the disk map
				//go to the block in disk indicated by the disk map
				
			if (oft.getPosition(OFTindex) == -1){
				cout << "error: specified file could not be closed, as it is not open" << endl;
				return -1;
			}
			int descIndex = oft.getIndex(OFTindex);
			//cout << "index of item at " << OFTindex << " is "<< descIndex << endl;
			int length = oft.getLength(OFTindex);
			//cout << "length of item at " << OFTindex << " is "<< length << endl;
			int blockNum = oft.getPosition(OFTindex) / 64; //(ranges from 0-2)
			//cout << "blockNUm of item at " << OFTindex << " is "<< blockNum << endl;
			
			int ldisk_index = descriptorGetDiskBlockIndex(descIndex, blockNum);
			//cout << "we will write oftindex " << OFTindex << " to ldisk block " << ldisk_index << endl;
			IO.write_block (ldisk_index, oft.table[OFTindex]);
			
			//update file length in descriptor
			descriptorSetLength(descIndex, length);
			
			//free up the OFT entry
			oft.setPosition(OFTindex, -1);
			
			//return status to ensure no error occurred
			return 1;
		}
		
		int read(int OFTindex, char* mem_area, int count) {
			//compute relative position in r/w buffer, depending on which disk block of a file is being accessed
				//the file has positions ranging from 0-63, 64-127, 128-191. But OFT r/w buffer can only hold one block, indexed as 0-63
				//basically, do position % 64 to convert from file position to r/w buffer indexes
				
			//cout << "trying to read from oft index " << OFTindex << " for " << count << " bytes" << endl;
			
			if (oft.getPosition(OFTindex) == -1){
				cout << "error: could not read specified file as it is not open" << endl;
				return -1;
			}
			int start_length = oft.getLength(OFTindex); //current length of the file
			int raw_pos = oft.getPosition(OFTindex); //value between 0-191
			//cout << "raw position detected as " << raw_pos << endl;
			int local_pos = raw_pos % 64; //value between 0-63
			//cout << "local position detected as " << local_pos << endl;
			int current_block = raw_pos / 64; //value between 0-2
			//cout << "current block detected as " << current_block << endl;
			int descIndex = oft.getIndex(OFTindex); //index of the file descriptor, in case we need to read the next block, value between 0-23
			
			//cout << "descIndex found: " << descIndex << endl;
			
			//copy from r/w buffer to memory until:
				// 1. desired count or end of file reached: update current position and return status
				// 2. end of buffer reached: write current block (in r/w buffer) to disk, read next block, continue copying
				
			int bytes_read = 0; //tracks how many bytes we were able to read before the loop terminates
			//starting at the current position, copy bytes from the buffer into memory.
			for (bytes_read = 0; bytes_read < count; bytes_read++){ //continues until count is reached, or is interrupted by break
				//cout << "bytes read: " << bytes_read << endl;
				if (bytes_read + raw_pos >= start_length){ //if we have reached the end of the file
					//cout << "read has reached the end of the file" << endl;
					break; //interrupts when we have reached the end of the file
				}
				else if (local_pos > 63){ //if we have reached the end of the buffer but still have some count remaining
					//cout << "end of buffer reached, but some count still remains" << endl;
					IO.write_block(descriptorGetDiskBlockIndex(descIndex, current_block), oft.table[OFTindex]); //write buffer to disk
					IO.read_block(descriptorGetDiskBlockIndex(descIndex, current_block + 1), oft.table[OFTindex]); //read the next block
					current_block += 1;
					//cout << "current block updated to " << current_block << endl;
					local_pos = 0; //reset local_pos to 0, since we are in a new block
				}
				
				mem_area[bytes_read] = oft.table[OFTindex][local_pos];
				//cout << "read item " << oft.table[OFTindex][local_pos] << " from OFT entry " << OFTindex << " at local position " << local_pos << endl;   
				local_pos += 1;
				//cout << "local_pos updated to " << local_pos << endl;
			}
			oft.setPosition(OFTindex, raw_pos + bytes_read); //update oft position
		
			return bytes_read;
		}
	
		int write(int OFTindex, char mem_area, int count)
		{
			if (oft.getPosition(OFTindex) == -1){
				cout << "error: could not write to specified file as it is not open" << endl;
				return -1;
			}
			//compute relative position in the r/w buffer
			int start_length = oft.getLength(OFTindex); //current length of the file
			int raw_pos = oft.getPosition(OFTindex); //value between 0-191
			//cout << "raw position detected as " << raw_pos << endl;
			int local_pos = raw_pos % 64; //value between 0-63
			//cout << "local position detected as " << local_pos << endl;
			int current_block = raw_pos / 64; //value between 0-2
			//cout << "current block detected as " << current_block << endl;
			int descIndex = oft.getIndex(OFTindex); //index of the file descriptor, in case we need to read the next block, value between 0-23
			//cout << "descriptor index found at " << descIndex << endl;
			
			//cout << "during write for oft index " << OFTindex << ", we will write to ldisk number " << descriptorGetDiskBlockIndex(descIndex, current_block)<<endl;
			
			//copy from memory to r/w buffer until:
				// 1. desired count or end of file (max file size) reached: update current position and return status
				// 2. end of buffer reached:
					//if next block does not exist yet (file is expanding)
						//allocate new block (search and update bit map)
						//update file descriptor with this new block number
					//write current buffer to disk
					//continue copying
			int bytes_written = 0; //tracks how many bytes we were able to write before the loop terminates
			//starting at the current position, copy bytes from the buffer into memory.
			for (bytes_written = 0; bytes_written < count; bytes_written++){ //continues until count is reached, or is interrupted by break
				if (bytes_written + start_length >= 192){ //if we have reached the maximum size of a file (192 bytes)
					//cout << "max file size reached. ending write." << endl;
					break; //interrupts since we have no more space to write
				}
				else if (local_pos > 63){ //if we have reached the end of the buffer but still have some count remaining
					//cout << "end of buffer reached, but some count still remains" << endl;
					if (descriptorGetDiskBlockIndex(descIndex, current_block + 1) == -1){ //if next block does not exist yet
						//cout << "next block does not exist yet. creating..." << endl;
						int new_index = BM.searchFor0(); //search in bit map for an empty block
						//cout << "write found empty bit in bitmap at index " << new_index << endl;
						BM.setTo1(new_index); //update bit map to fill the block we found
						//update_disk_BM();
						//BM.printBitMap();
						descriptorSetDiskBlockIndex(descIndex, current_block + 1, new_index); //update file descriptor with this new block number
						//cout << "new block in data position " << current_block + 1 << ": disk block " << descriptorGetDiskBlockIndex(descIndex, current_block + 1) << endl;
					}
					
					IO.write_block(descriptorGetDiskBlockIndex(descIndex, current_block), oft.table[OFTindex]); //write current buffer to disk
					IO.read_block(descriptorGetDiskBlockIndex(descIndex, current_block + 1), oft.table[OFTindex]); //read the next block into buffer
					current_block += 1; //update current_block
					//cout << "current block updated to " << current_block << endl;;
					local_pos = 0; //reset local_pos to 0, since we are in a new block
				}
				
				oft.table[OFTindex][local_pos] = mem_area;
				//cout << "wrote item " << oft.table[OFTindex][local_pos] << " to  OFT entry " << OFTindex << " at local position " << local_pos << endl;   
				//cout << "test" << endl;
				local_pos += 1;
				}
			descriptorSetLength(descIndex, start_length + bytes_written); //update file descriptor length
			oft.setLength(OFTindex, start_length + bytes_written); //update oft length
			oft.setPosition(OFTindex, raw_pos + bytes_written);
		
			return bytes_written; //return #bytes written
		}

		int lseek(int OFTindex, int newPosition){
			//if the new position is not in the current block,(position ranges from 0-63, 64-127, 128-191)
				//write the buffer to disk
				//read the new block into buffer
			//set the current position to the new position
			//return status
			//cout << "attempting to seek positon " << newPosition << " for oft index " << OFTindex << endl;
			
			if (oft.getPosition(OFTindex) == -1){
				cout << "error: could not seek in specified file as it is not open" << endl;
				return -1;
			}
			if (newPosition > oft.getLength(OFTindex)){
				cout << "error: cannot seek past the end of OFTentry " << OFTindex << ", which has length of " << oft.getLength(OFTindex) << endl;
				return -1;
			}
				
			int new_block = positionToBlockNum(newPosition); //the block we want to go to
			//cout << "we want to go to position " << newPosition <<", which is in block " << new_block << endl;
			int current_position = oft.getPosition(OFTindex);
			int current_block = positionToBlockNum(current_position); //the block we start in
			//cout << "we are currently at position " << current_position << ", which is in block " << current_block << endl;
			
			if (current_block != new_block){ //if the new position is not in the current block(position ranges from 0-63, 64-127, 128-191)
				//cout << "our new position is not in the same block as the current position" << endl;
				int descIndex = oft.getIndex(OFTindex); //index of the file descriptor
				IO.write_block(descriptorGetDiskBlockIndex(descIndex, current_block), oft.table[OFTindex]); //write buffer to disk
				IO.read_block(descriptorGetDiskBlockIndex(descIndex, new_block), oft.table[OFTindex]); //read the new block into buffer
			}
				
			oft.setPosition(OFTindex, newPosition); //set the current position to the new position
			return 1; //return status		
		}
		
		int positionToBlockNum(int position){
			//given a position within a file, calculates which of the 3 blocks that position is in.
			if (position < 64){
				return 0;
			}
			else if (position < 128){
				return 1;
			}
			else if (position >= 128){
				return 2;
			}
		}
		
		int descIndexToBlock(int descIndex){
			//given the index of a file descriptor, calculates the block in disk where it can be found.
			if (descIndex < 4){
				return 1;
			}
			else if (descIndex < 8){
				return 2;
			}
			else if (descIndex < 12){
				return 3;
			}
			else if (descIndex < 16){
				return 4;
			}
			else if (descIndex < 20){
				return 5;
			}
			else if (descIndex >= 20){
				return 6;
			}
		}
		
		string directory(){
			//seek to beginning of directory
			//for each non-empty entry, print the file name
			
			stringstream outStr;
			lseek(0,0); //seek to beginning of directory file
			char temp [192];
			int bytes_read = read(0, temp, 192); //read directory into local char* temp
			int * temp2 = (int *) temp; //typecast directory into array of integers, 2 integers per slot.
			int temp2_size = bytes_read / 4; //size of the integer type-casted array. ranges from 0-48 (192 / 4 since 4 char = 1 int)
			
			for (int i = 0; i < temp2_size; i+=2){ //for each slot in the directory
				if (temp2[i + 1] != -1){ //if a file exists
					for (int j = 0; j < 4; j++){
						outStr << temp[i + j]; //print that file's symbolic name
					}
					outStr << " ";
				}
			}
			//outStr << endl;
			
			return outStr.str();
		}
	
		void init(){
			IO = IOSys();
			oft = OFT(IO);
			BM = BitMap();
			
			//update_disk_BM(); //set bit map
			open_directory();
			//BM.printBitMap();
		}
		
		void init(char* filename){
			//restore ldisk from file.txt
			
			//read from an external file into ldisk
			
			IO = IOSys();
			oft = OFT(IO);
			BM = BitMap();
			
			//update_disk_BM(); //set bit map
			//BM.printBitMap();
			
			ifstream inFile;
			inFile.open(filename);
			
			//read the bit map
			string line = "";
			getline(inFile, line);
			
			char temp[line.length() + 1];
			memcpy(temp, line.c_str(), line.length() + 1);
			char * tok = strtok(temp, " "); //must say this here so we can load the first bit
			
			for (int i = 0; i < 64; i++){
				
				int new_bit = strtol(tok, NULL, 0);
				//cout << "new token: " << tok << endl;
				if (new_bit == 1){
					BM.setTo1(i);
				}
				else if (new_bit == 0){
					BM.setTo0(i);
				}
				
				tok = strtok(NULL, " ");
			}
			
			//cout << "loaded bitmap: " << endl;
			//BM.printBitMap();
			
			//load descriptor entries (blocks 1-6)
			char to_load [64];
			int * to_load_ints = (int*) to_load;
			
			for (int i = 1; i < 7; i++){ //for each block
				//cout << "now reading line " << i << endl;
				getline(inFile, line);
				char temp[line.length() + 1];
				memcpy(temp, line.c_str(), line.length() + 1);
				char * tok = strtok(temp, " ");
				for (int j = 0; j < 16; j++){ //for each of the 16 integers in this block
					int new_int = strtol(tok, NULL, 10);
					//cout << "new token: " << new_int << endl;
					to_load_ints[j] = new_int;
					tok = strtok(NULL, " ");
					}
				IO.write_block(i, to_load);
			}
			
			//load remaining disk blocks
			int dir_blocks[3];
			dir_blocks[0] = descriptorGetDiskBlockIndex(0, 0);
			dir_blocks[1] = descriptorGetDiskBlockIndex(0, 1);
			dir_blocks[2] = descriptorGetDiskBlockIndex(0, 2);
			
			//cout << "dir block 0 is " << dir_blocks[0] << ", dir block 1 is " << dir_blocks[1] << ", and dir block 2 is " << dir_blocks[2] << endl;
			
			char to_load_2 [64];
			int * to_load_ints_2 = (int*) to_load_2;
			
			for (int i = 7; i < 64; i++){ //for each line in the file
			
				//cout << "accessing file line " << i << endl;
				
				getline(inFile, line);
				//cout << "line: " << line << endl;
				char temp[line.length() + 1];
				memcpy(temp, line.c_str(), line.length() + 1);
				char * tok = strtok(temp, " ");
				
				if (i != dir_blocks[0] && i != dir_blocks[1] && i != dir_blocks[2]){ //if this block is not a directory block (since we have to treat directory blocks differently)
					for (int j = 0; j < 64; j++){ //for each of the 64 bytes in this block
						//cout << "block is not a directory block" << endl;
						if (strtol(tok, NULL, 10) == -1){
							to_load_2[j] = -1;
						}
						else{
							char * new_byte = tok;
							//cout << "new token: " << new_byte << endl;
							to_load_2[j] = new_byte[0];
						}
						
						tok = strtok(NULL, " ");
					}
				}
				else{ //if this block is a directory block
					for (int k = 0; k < 16; k++){ //for each of the integers in one block of the directory
						if (k % 2 == 0){//if k is even, we expect a name
							//cout << "access even integer " << k << " of a directory block" << endl;
							int test_int = strtol(tok, NULL, 0);
							//cout <<"test int is " << test_int << endl;
							if (test_int != 0){ //if there actually isn't a name here
								//cout << "no name here" << endl;
								to_load_ints_2[k] = test_int;
								}
							else{
								char * new_word = tok;
								//cout << "new word " << new_word << endl;
								int * new_int = (int *) new_word;
								//cout << "new int " << new_int << endl;
								to_load_ints_2[k] = new_int[0];
								//cout << "no error yet" << endl;
								//cout << "new directory token: " << new_int << endl;
								//cout << "token is really: " << (char*) new_int << "." << endl;
								//cout << "test1" << endl;
								//cout << "test2" << endl;
								//cout << "test2.5" << endl;
							}
						}
						else if (k % 2 == 1){ //if k is odd, we expect an integer
							//cout << "access odd integer " << k << " of a directory block" << endl; 
							if (tok == NULL){
								//cout << "token is null" << endl;
							}
							//cout << "raw tok " << tok << endl;
							int new_int = strtol(tok, NULL, 10);
							//cout << "new int obtained: " << new_int << endl;
							to_load_ints_2[k] = new_int;
							
						}
						tok = strtok(NULL, " ");
						//cout << "updated tok after k value " << k << endl;
					}
					
				}
				
				//cout << "test3" << endl;
				IO.write_block(i, to_load_2);
				//cout << "test4" << endl;
			}
			
			//cout << "test3" << endl;
			open_directory();
			
			//cout << "foo's descIndex is " << findFileDescriptorIndex((char*)"foo") << endl;
						
			//cout << "test4" << endl;
			inFile.close();
			
			//BM.printBitMap();
			//cout << "disk after load: " << endl;
			//print_disk();
			
			return;
		} 
		void save(char* filename){
			//save ldisk  to file.txt
			//cout<< " NOW SAVING>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
			//cout << "bitmap before save: " << endl;
			//BM.printBitMap();
			
			for (int i = 0; i < 4; i++){ //close all open files including directory
				if (oft.getLength(i) != -1){
					close(i);
					//cout << "closed oft entry " << i << endl;
				}
			}
			
			ofstream outfile;
			outfile.open(filename);
			
			string to_return [64]; //this will hold the file before we output it
			
			//saving the bit map on the first line of the file
			to_return[0] = BM.getBM();
			//BM.printBitMap();
			
			//saving directory blocks
			int dir_blocks[0];
			dir_blocks[0] = descriptorGetDiskBlockIndex(0, 0);
			dir_blocks[1] = descriptorGetDiskBlockIndex(0, 1);
			dir_blocks[2] = descriptorGetDiskBlockIndex(0, 2);
			
			for (int i = 0; i < 2; i++){ //for each of potentially 3 disk blocks alloc to the directory
				if (dir_blocks[i] != -1){ //if the directory allocated this block
					char dir_temp[64];
					IO.read_block(dir_blocks[i], dir_temp); //read the disk block into dir_temp
					int * dir_temp2 = (int*) dir_temp; //casts 64-byte array to 16-integer array, or 8-slot array
					
					for (int j = 0; j < 16; j+=2){ //for each of the 8 slots in this block of the directory
						if (dir_temp2[j] == -1){ //if a directory entry was not allocated (name is -1)
							to_return[dir_blocks[i]] += "-1 -1 ";
							}
						else{ //if a directory entry was allocated
							for (int k = 0; k < 4; k++){ //for each char in the symbolic file name 
								if (dir_temp[j*4+k] != 0){ //j * 4 
									to_return[dir_blocks[i]] += dir_temp[j * 4 + k]; //output that char
									//cout << "output item: " << dir_temp[j*4 +k] << endl;
								}
							}
							
							int descIndex = dir_temp2[j*2 + 1];
							to_return[dir_blocks[i]] += " ";
							to_return[dir_blocks[i]] += to_string(descIndex); //write the desc Index
							//cout << "printing desc index " << descIndex << endl;
							to_return[dir_blocks[i]] += " ";
							//cout << "dir_block " << i << " is " << to_return[dir_blocks[i]]<< endl; 
							
							}
					}
					
				}
			}
			
			//saving the descriptors from blocks 1-6
			for (int i = 1; i < 7; i++){ //for each of the 6 blocks, each of which contains 4 descriptor slots, each of which is 4 integers long, output
				char temp_block[64];
				IO.read_block(i, temp_block);
				int* temp_block2 = (int *) temp_block; //casts 64-byte array to 16-integer array, or 4-slot array
				
				for(int j = 0; j < 4; j++){ //for each of the 4 slots in one block
					for(int k = 0; k < 4; k++){ //for each of the 4 ints in a slot
						to_return[i] += to_string(temp_block2[j*4 + k]) + " ";
					}
				}
			}
			
			//save remaining ldisk blocks
			
			for (int i = 7; i < 64; i++){ //for each of the remaining disk blocks
				if (i != dir_blocks[0] && i != dir_blocks[1] && i != dir_blocks[2]){ //if it is not a directory block, since we already did those
					char to_write[64];
					IO.read_block(i, to_write); //read the disk block into to_write
					//cout << "read block " << i << ": " << to_write << endl;
					for (int j = 0; j < 64; j++){ //for each char in this block
						if (to_write[j] == -1){
							to_return[i] += "-1 ";
						}
						else{
							to_return[i] += to_write[j]; //write to_write to a line of an external file
							to_return[i] += " ";
						}
					}
					
				}
			}
			
			for (int i = 0; i < 64; i++){
				outfile << to_return[i] << endl;
			}
			outfile.close();
			
			//we should end with a 64-line file with 64 characters on each line
		}
		void printBitMap(){
			BM.printBitMap();
		}
		
		int findFileDescriptorIndex(char* symbolic_file_name){
			//given a symbolic file name, look through directory to find the index of that file's descriptor. If it doesn't exist, returns -1.
			
			lseek(0,0); //seek to beginning of directory file
			char temp [192];
			int bytes_read = read(0, temp, 192); //read directory into local char* temp
			int * temp2 = (int *) temp; //typecast directory into array of integers, 2 integers per slot.
			int * symbolic_int = (int *) symbolic_file_name; //casts our file name into an integer for easier comparison
			int temp2_size = bytes_read / 4; //size of the integer type-casted array. ranges from 0-48 (192 / 4 since 4 char = 1 int)
			
			//cout << "directory: " << endl;
			
			for (int i = 0; i < temp2_size; i+=2){ //for each slot in the directory
				if (temp2[i] == symbolic_int[0]){ //if we have found the directory entry of the file we want
					//cout << "findFileDescriptorIndex found descindex for " << symbolic_file_name << " at index " << temp2[i+1] << endl;
					return temp2[i + 1];
				}
			}
			return -1;
		}
			
		int descriptorGetLength(int slot){
			//given the slot of a file descriptor (ranges from 0-23), return its length
			//descriptors are 4 per block * 6 blocks = 24 possible.
			//descriptors are each 4 integers long
			int blockNum = slot / 4 + 1; //ranges from 1-6
			//cout << "descriptorgetlength for descIndex " << slot << " has blocknum of " << blockNum << endl;
			int offset = slot % 4; //ranges from 0-3
			//cout << "descriptorgetlength for descIndex " << slot << " has offset of " << offset << endl;
			
			char temp[64];
			IO.read_block(blockNum, temp); //read the appropriate block
			int* temp2 = (int *) temp; //typecast block to to 16 integers = 4 descriptor slots
			//cout << "descriptor index " << slot << " has length of " << temp2[offset * 4] << endl;
			return temp2[offset * 4];
		}
		
		void descriptorSetLength(int slot, int length){
			//given the slot of a file descriptor (ranges from 0-23) and a new length, set its length to this new length
			//descriptors are 4 per block * 6 blocks = 24 possible.
			//descriptors are each 4 integers long
			int blockNum = slot / 4 + 1;
			int offset = slot % 4;
			
			char temp[64];
			IO.read_block(blockNum, temp); //read the appropriate block
			int* temp2 = (int *) temp; //typecast block to to 16 integers = 4 descriptor slots
			temp2[offset * 4] = length;
			IO.write_block(blockNum, temp);
		}
		
		int descriptorGetDiskBlockIndex(int descIndex, int diskMapIndex){
			//given the slot of a file descriptor in ldisk blocks 1-6 (ranges from 0-23) and a disk map index (ranges from 0-2), return the number stored in that disk map index
			// the number returned is the ldisk block where that segment of the file's data can be found.
			//descriptors are 4 per block * 6 blocks = 24 possible
			
			int blockNum = descIndex / 4 + 1; //ranges from 1-6 (block 0 os the bitmap, ignore that)
			int offset = descIndex % 4; //ranges from 0-3. tells us which slot in a directory block holds our descriptor
			
			char temp[64];
			IO.read_block(blockNum, temp); //read the directory block containing our file descriptor
			int* temp2 = (int *) temp; //typecast block to 16 integers = 4 descriptor slots
			//cout << "descriptorGetDiskBlockIndex found disk number "<< diskMapIndex << " for descriptor index " << descIndex << " at ldisk index" << temp2[offset * 4 + 1 + diskMapIndex] << endl;
			return temp2[offset * 4 + 1 + diskMapIndex]; //offset * 4 brings us to the descriptor slot | +1 brings us to its disk map | diskMapIndex brings us to an entry in the dosk map
			
		}
		
		int descriptorSetDiskBlockIndex(int descIndex, int diskMapIndex, int new_index){
			//given the slot of a file descriptor (ranges from 0-23), a disk map index (ranges from 0-3), store the new index in that disk map index
			// the number returned is the ldisk block where that segment of the file's data cane be found.
			//descriptors are 4 per block * 6 blocks = 24 possible
			
			int blockNum = descIndex / 4 + 1;
			int offset = descIndex % 4;
			
			char temp[64];
			IO.read_block(blockNum, temp); //read the appropriate block
			int* temp2 = (int *) temp; //typecast block to to 16 integers = 4 descriptor slots
			temp2[offset * 4 + 1 + diskMapIndex] = new_index;
			IO.write_block(blockNum, temp);
			
		}

		void print_disk(){
			char to_write[64];
				for (int i = 0; i < 64; i++){
					IO.read_block(i, to_write);
					cout << "data in ldisk block  "<< i << ": " << to_write << endl;
				}
		}
		/*void update_disk_BM(){
			int* raw_BM = BM.getBM();
			char * alt_BM = (char* )raw_BM;
			char to_write [64];
			for (int i = 0; i < 64; i++){
				if (i < 8){
					to_write[i] = alt_BM[i];
				}
				else{
					to_write[i] = -1;
				}
			}
			
			IO.write_block(0, to_write);
		}*/
};

//int bitmap [64]; //bitmap/directory [bitmap length in bits]
//ldisk [0] = bitmap;
//ldisk[1-6] = file descriptors, 4 per block
//ldisk[7-64] = data blocks

//file descriptor = 4-tuple with length of file, disk block 1, disk block 2, disk block 3


