#include <iostream>
using namespace std;

//extract VA = spw into sp and w
//search TLB for match on SP
	//if TLB hit,
		//use f from TLB to form PA = f + w
		//assume match in line k. decrement all LRU values that are greater than LRU[k]
		//set LRU[k] = 3
	//if TLB miss,
		//resolve VA as before
		//in case of error or page fault, no change to TLB
		//if a valid PA is derived from VA then update TLB:
			//select line with LRU = 0 and set to LRU = 3
			//replace sp field of that line with the new sp value
			//replace f field of that line with PM[PM[s] + p]
			//decrement all other LRU values by 1

class TLB{
	public:
		int buffer[4][3];
		//4 lines in table, each includes LRU (int ranging from 0-3, 0 least recent, 3 most recent), segment & page, frame
		//note: f is frame, but it is the starting frame address, not the frame #
		int mask9; //mask for last 9 bits of a number
		int mask19; //mask for last 19 bits of a number
		
		TLB(){
			for (int i = 0; i < 4; i++){
				for (int j = 0; j < 3; j++){
					buffer[i][j] = -1; //initialize table with -1's
				}
			}
			for (int i = 0; i < 4; i++){
				buffer[i][0] = i; //initialize LRU
			}
			mask9 = 1; 
			for (int i = 0; i < 8; i++){ //initialize mask9
				mask9 = mask9 << 1;
				mask9 += 1;
			}
			mask19 = 1; 
			for (int i = 0; i < 18; i++){ //initialize mask19
				mask19 = mask19 << 1;
				mask19 += 1;
			}
		}
		~TLB(){
		}
		
		int find_hit(int VA){
			int w = VA & mask9;
			int sp = (VA >> 9) & mask19;
			
			//cout << " w is " << w << endl;
			
			for (int i = 0; i < 4; i++){
				if (sp == buffer[i][1]){ //if TLB hit:
					//cout << "TLB: TLB has hit on index " << i << endl;
					int PA = buffer[i][2] + w; //use f from TLB to form PA = f + w
					//cout << "TLB's f value is " << buffer[i][2] << endl;
					//cout << "add " << buffer[i][2] << "to w value " << w << " = " << buffer[i][2] + w << endl;
					update_LRU(i);
					return PA;
				}
			}
			//cout << "failed to find TLB item" << endl;
			return -1;
		}
		
		void update_TLB_from_miss(int VA, int f){ //if a valid PA is derived from VA then update TLB:
			int sp = (VA >> 9) & mask19;
			
			for (int i = 0; i < 4; i++){
				if (buffer[i][0] == 0){ 
					buffer[i][0] = 3; //select line with LRU = 0 and set to LRU = 3
					buffer[i][1] = sp; //replace sp field of that line with the new sp value
					buffer[i][2] = f; //replace f field of that line with PM[PM[s] + p]
					for (int j = 0; j < 4; j++){
						if (j != i){
							buffer[j][0] -= 1; //decrement all other LRU values by 1
						}
					}
				}
			}
			
		}
		
		void update_LRU(int k){ //assume match in line k. decrement all LRU values that are greater than LRU[k]
			int old_value = buffer[k][0];
			
			for (int i = 0; i < 4; i++){
				if (buffer[i][0] > old_value){
					buffer[i][0] -= 1;
				}
			}
			buffer[k][0] = 3; //set LRU[k] = 3
		}
};
