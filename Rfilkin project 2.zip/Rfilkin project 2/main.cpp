#include <fstream>
#include <string.h>
#include <iostream>
#include <sstream>
#include <cstring>
#include "phys_mem.cpp"
using namespace std;

int main(){
	phys_mem PM = phys_mem();
	bool use_TLB = false;
	
	string input_file1 = "input1.txt"; //for initializing the Virtual Memory
	//string input_file1 = "initFile-7.txt"; //for initializing the Virtual Memory
	string input_file2 = "input2.txt"; //contains Virtual Addresses to be translated
	//string input_file2 = "opFile-7.txt"; //contains Virtual Addresses to be translated
	string line = "";
	
	string output_file1 = "678368371.txt";
	string output_file2 = "678368372.txt";
	
	ofstream outFile;
	if (!use_TLB){
		outFile.open(output_file1);
	}
	else{
		outFile.open(output_file2);
	}
		
	//initializing VM
	
	//read first input file
		//for the first line, series of tuples "s f" (make entries into ST)
			//PT of segment s starts at address f, so ST[s] = f, or PM[s] = f
		//for second line, series of triples "p s f" (make entries into PT)
			//page p of segment s starts at index f, so ST[s] -> PT[p] = f, or PM[PM[s] + p] = f
		//create bitmap to show which frames are free
	
	ifstream inFile1;
	inFile1.open(input_file1);
	
	getline(inFile1, line); //first line: series of tuples "s f"
	char temp_sf[line.length() + 1];
	memcpy(temp_sf, line.c_str(), line.length() + 1);
	
	//cout << "test2" << endl;
	
	char * tok_sf = strtok(temp_sf, " "); //initializes token
	while (tok_sf != NULL){
		int s = atoi(tok_sf); //translates token into integer, here extracts s
		//cout << "token is: " << tok_sf << ", and s is: " << s << endl;
		tok_sf = strtok(NULL, " ");
		int f = atoi(tok_sf); //extract f
		//cout << "token is: " << tok_sf << ", and f is: " << f << endl;
		PM.init_line1(s, f); //send s and f to PM
		tok_sf = strtok(NULL, " "); //moves token forward
	}
	
	//cout << "onto line 2-----------------------------" << endl;
	getline(inFile1, line); //second line: series of triples "p s f"
	char temp_psf[line.length() + 1];
	memcpy(temp_psf, line.c_str(), line.length() + 1);
	
	char * tok_psf = strtok(temp_psf, " ");
	int tuple_place = 0;
	while (tok_psf != NULL){
		int p = atoi(tok_psf); //translates token into integer, here extracts p
		//cout << "token is: " << tok_psf << ", and p is: " << p << endl;
		tok_psf = strtok(NULL, " ");
		int s = atoi(tok_psf); //extract s
		//cout << "token is: " << tok_psf << ", and s is: " << s << endl;
		tok_psf = strtok(NULL, " ");
		int f = atoi(tok_psf); //extract f
		//cout << "token is: " << tok_psf << ", and f is: " << f << endl;
		PM.init_line2(p, s, f); //send p, s, and f to PM
		tok_psf = strtok(NULL, " "); //moves token forward
	}
	
	//translating VA's
	
	//read second input file
		//series of tuples "o VA"
			//each o is either 0 (read) or 1 (write)
			//each VA is a positive integer (virtual address) in format (4 blank bits), (9 bits for segment #), (10 bits for page #), (9 bits for word #)
		//for each "o VA" pair, attempt to translate the VA to PA
		//write results to an output file
	
	//cout << "onto second input file ------------------------------" << endl;
	ifstream inFile2;
	inFile2.open(input_file2);
	
	getline(inFile2, line); //first line: series of tuples "o VA"
	char temp_va[line.length() + 1];
	memcpy(temp_va, line.c_str(), line.length() + 1);
	
	char * tok_va = strtok(temp_va, " "); //initializes token
	while (tok_va != NULL){
		int o = atoi(tok_va); //translates token into integer, here extracts o
		tok_va = strtok(NULL, " ");
		int VA = atoi(tok_va); //extract VA
		//cout << "VA is: " << VA << endl;
		
		if (!use_TLB){ //not using TLB
		//cout << "not using TLB" << endl;
			if (o == 0){
				//cout << "read operation" << endl;
				outFile << PM.read_page(VA) << " ";
				//cout << "complete" << endl;
			}
			else if (o == 1){
				//cout << "write operation" << endl;
				outFile << PM.write_page(VA) << " ";
				//cout << "complete" << endl;
			}
		}
		else if (use_TLB){ //using TLB
		//cout << "using TLB" << endl;
			if (o == 0){
				outFile << PM.read_page_TLB(VA) << " ";
			}
			else if (o == 1){
				outFile << PM.write_page_TLB(VA) << " ";
			}
		}
		
		tok_va = strtok(NULL, " "); //moves token forward
	}
	inFile1.close();
	inFile2.close();
	outFile.close();
}
