//I/O system - implement as an object with ldisk as a private variable, and read_block and write_block as methods.

class IOSys{
	private:
		int LDISK_NUM_OF_BLOCKS = 64;
		int BLOCK_LENGTH_IN_BYTES = 64; //== 16 integers
		int BITMAP_LENGTH_IN_BYTES = 8; //== 64 bits == 2 integers
		char ldisk[64][64];
	public:
		IOSys(){
			//we define ldisk as a 2-dimensional byte array, where the first index is block # and the second is byte #
			//since bitmap is only 8 bytes long, we will have several empty byte cells in block 0
			
			//we initialize the entire array with every byte being empty
			for (int i = 0; i < 64; i++){
				for(int j = 0; j < 64; j++){
					ldisk[i][j] = -1; //-1 indicates that a byte is empty
				}
			}
		}
		~IOSys(){
		}
		void write_block(int i, char* p){
			//accesses block i in ldisk, and copies main memory *p into it
			//cannot write individual bytes; must replace an entire block at a time
			for(int j = 0; j < 64; j++)
			{
				ldisk[i][j] = p[j];
			}
		}
		void read_block(int i, char* p){
			//accesses block i in ldisk, and copies it to main memory *p
			//cannot write individual bytes; must replace an entire block at a time
			for(int j = 0; j < 64; j++)
			{
				p[j] = ldisk[i][j];
			}
		}
		
};

//char ldisk [64][64]; //ldisk [ldisk num of blocks] [block length in bytes]
//int bitmap [64]; //bitmap/directory [bitmap length in bits]
//ldisk [0] = bitmap;
//ldisk[1-6] = file descriptors, 4 per block
//ldisk[7-64] = data blocks

//file descriptor = 4-tuple with length of file, disk block 1, disk block 2, disk block 3


//main memory *p could be a byte array, but must have type-casting. It must be read/writeable for bytes/chars and integers
//implement ldisk as an object with only read_block and write_block as methods.
