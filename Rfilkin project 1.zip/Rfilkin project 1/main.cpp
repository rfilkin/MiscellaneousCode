#include "FileSystem.cpp"
#include <sstream>
#include <fstream>
#include <cstring>
#include <string.h>
using namespace std;

int main(){
	FileSys FS = FileSys();
	
	//string input_file = "test_input.txt";
	string input_file = "input.txt";
	ifstream inFile;
	inFile.open(input_file);
	
	string output_file = "67836837.txt";
	ofstream outFile;
	outFile.open(output_file);
	
	string line = "";
	
	bool quit = false;
	while (getline(inFile, line)){
		
		//cout << "line: " << line << endl;
		//char* temp = strdup(line.c_str());
		char temp[line.length() + 1];
		memcpy(temp, line.c_str(), line.length() + 1);
		
		/*for(int i = 0; i < line.length();i++){
			temp[i] = line[i];
		}*/
		
		char * tok = strtok(temp, " ");
		//cout << "token: " << tok << endl;
		
		if (tok == NULL){
			outFile << endl;
		}
		
		else if ((string)tok == "cr"){ //create <name>
			tok = strtok(NULL, " ");
			char* name = tok;
			if(FS.create(tok) == -1){
				outFile << "error" << endl;
			}
			else{
				outFile << name << " created" << endl;
			}
		}
		else if ((string)tok == "de"){ //destroy <name>
			tok = strtok(NULL, " ");
			char* name = tok;
			if (FS.destroy(tok) == -1){
				outFile << "error" << endl;
			}
			else{
				outFile << name << " destroyed" << endl;
			}
		}
		else if ((string)tok == "op"){ //open <name>
			tok = strtok(NULL, " ");
			//cout << "op name -> " << tok << endl;
			char* name = tok;
			int index = FS.open(tok);
			if (index == -1){
				outFile << "error" << endl;
			}
			else{
				outFile << name << " opened " << index << endl;
			}
		}
		else if ((string)tok == "cl"){ //close <index>
			tok = strtok(NULL, " ");
			int index = atoi(tok);
			if (FS.close(index) == -1){
				outFile << "error" << endl;
			}
			else{
				outFile << index << " closed" << endl;
			}
			
		}
		else if ((string)tok == "rd"){ //read <index> <count>
			tok = strtok(NULL, " "); //index
			int index = atoi(tok);
			tok = strtok(NULL, " "); //count
			int count = atoi (tok);
			char to_print [count];
			if(FS.read(index, to_print, count) == -1){
				outFile << "error" << endl;
			}
			else{
				outFile << to_print << endl;
			}
			
			
		}
		else if ((string)tok == "wr"){ //write <index> <char> <count>
			tok = strtok(NULL, " "); //index
			//cout << "wr index -> " << tok << endl;
			int index = atoi(tok);
			tok = strtok(NULL, " "); //char
			//cout << "wr char -> " << tok << endl;
			char c = tok[0];
			tok = strtok(NULL, " "); //count
			//cout << "wr count -> " << tok << endl;
			int count = atoi (tok);
			if (FS.write(index, c, count) == -1){
				outFile << "error" << endl;
			}
			else{
				outFile << count << " bytes written" << endl;
			}
			
		}
		else if ((string)tok == "sk"){ //seek <index> <pos>
			tok = strtok(NULL, " "); //index
			//cout << "sk index -> " << tok << endl;
			int index = atoi(tok);
			
			tok = strtok(NULL, " "); //pos
			//cout << "sk pos -> " << tok << endl;
			int pos = atoi (tok);
			
			if (FS.lseek(index, pos) == -1){
				outFile << "error" << endl;
			}
			else{
				outFile << "position is "<< pos << endl;
			}
			
		}
		else if ((string)tok == "dr"){ //directory
			//tok = strtok(NULL, " ");
			outFile << FS.directory() << endl;
		}
		else if ((string)tok == "in"){ //init <disk_cont.txt>
			tok = strtok(NULL, " ");
			if (tok == NULL){
				FS.init();
				outFile << "disk initialized"<<endl;
			}
			else{
				//cout << "start rest" << endl;
				char* filename = tok;
				//cout << "starting restore for " << filename << endl;
				FS.init(filename);
				outFile << "disk restored" << endl;
			}
			
		}
		else if ((string)tok == "sv"){ //save <disk_cont.txt>
			tok = strtok(NULL, " ");
			char * filename = tok;
			FS.save(filename);
			outFile << "disk saved" << endl;
		}

		else{
			outFile << "error: line command not recognized: " << (string)tok << endl;
		}
	}
	
	//free temp;
	
	inFile.close();
	return 1;
}
