#include <iostream>
#include <sstream>
using namespace std;

class BitMap{
	private:
		int BM[2]; //bitmap with 2 integers
		int maskA[32]; //mostly 0's, but has 1's on diagonal
		int maskB[32]; //mostly 1's, but has 0's on diagonal
		string bit_delim = " ";
	public:
		BitMap(){
			
			maskA[31] = 1;
			for (int i = 30; i >= 0; i--){
				maskA[i] = maskA[i+1] << 1;
			}
			
			for (int i = 0; i < 32; i++){
				maskB[i] = ~maskA[i];
			}	
			
			for (int i = 0; i <= 6; i++){ //block 0 holds this bitmap, while blocks 1-6 hold file descriptors, so blocks 0-6 start filled
				setTo1(i);
			}
			
			for(int i = 7; i < 64; i++){ //initialize the remaining bits to 0
				setTo0(i);
			}
			
		}
		
		int searchFor0(){
			for (int i = 0; i < 2; i++){ //for each of the 2 integers
				for (int j = 0; j < 32; j++){ //for each of the 32 bits in an integer
					int test = BM[i] & maskA[j];
					if (test == 0){ //if test was zeroed-out, then bit j of integer i must be 0
						return (32 * i)+ j;
						//bit j of BM[i] is 0;
						//stop search
					}
				}
			}
			return -1; // if a 0 could not be found
		}
		
		int searchFor1(){
			for (int i = 0; i < 2; i++){ //for each of the 2 integers
				for (int j = 0; j < 32; j++){ //for each of the 32 bits in an integer
					int test = BM[i] & maskA[j];
					if (test != 0){ //if test wasn't zeroed-out, then bit j in integer i must be 1.
						return (32 * i) + j;
						//bit j of BM[i] is 1;
						//stop search
					}
				}
			}
			return -1; // if a 1 could not be found
		}
		
		int getBit(int index){
			int i = index / 32;
			int j = index % 32;
			int test = BM[i] & maskA[j];
			if (test == 0){
				return 0;
			}
			else if (test != 0){
				return 1;
			}
		}
			
		void setTo1(int index){
			//index ranges from (0-63)
			//index = (j * 32) + i
			int i = index / 32; 
			int j = index % 32;
			BM[i] = BM[i] | maskA[j]; //sets bit i of BM[j] to 1;
		}
		
		void setTo0(int index){
			int i = index / 32; 
			int j = index % 32;
			BM[i] = BM[i] & maskB[j]; //sets bit i of BM[j] to 0;
		}
		
		void printBitMap(){
			cout << "Bitmap: ";
			for (int i = 0; i < 2; i++){
				for (int j = 0; j < 32; j++){
					int test = BM[i] & maskA[j];
					if (test != 0){
						cout << 1 << " ";
					}
					else if (test == 0){
						cout << 0 << " ";
					}
					else {
						cout << "error ";
					}
					
					}
				}
			cout << endl;
		}
		
		string getBM(){
			
			stringstream BM_str;
			for (int i = 0; i < 64; i++){
				//cout <<"bit number " << i << " is " << getBit(i) << endl;
				BM_str << getBit(i) << bit_delim;
			}
			return BM_str.str();
		}
		
		~BitMap(){
		}
};
